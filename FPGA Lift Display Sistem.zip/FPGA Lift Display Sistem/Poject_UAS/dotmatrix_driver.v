// ============================================================
// Module  : dotmatrix_driver
// Fungsi  : Menggerakkan dot matrix 8x8 dengan teknik
//           multiplexing (scanning per baris)
//           Scanning 1kHz → tiap baris aktif ~125us
//           Cukup cepat agar mata tidak melihat kedipan
// ============================================================
module dotmatrix_driver (               // Modul driver untuk mengendalikan dot matrix 8x8
    input  wire       clk_1khz,         // Clock scanning 1 kHz

    // Data bitmap dari frame_rom
    input  wire [7:0] row0,             // Data LED untuk baris 0
    input  wire [7:0] row1,             // Data LED untuk baris 1
    input  wire [7:0] row2,             // Data LED untuk baris 2
    input  wire [7:0] row3,             // Data LED untuk baris 3
    input  wire [7:0] row4,             // Data LED untuk baris 4
    input  wire [7:0] row5,             // Data LED untuk baris 5
    input  wire [7:0] row6,             // Data LED untuk baris 6
    input  wire [7:0] row7,             // Data LED untuk baris 7

    // Output ke dot matrix
    // ROW  : active HIGH  (anoda baris)
    // COL  : active LOW   (katoda kolom)
    output reg  [7:0] row_sel,          // Memilih baris yang sedang aktif
    output reg  [7:0] col_data          // Data kolom untuk baris aktif
);
    reg [2:0] scan_idx;  // Menyimpan nomor baris yang sedang discan (0 sampai 7)

    initial begin
        scan_idx = 0;                   // Mulai scanning dari baris 0
        row_sel  = 8'b00000001;         // Baris awal yang aktif
        col_data = 8'hFF;              // Semua kolom mati saat awal
    end

    always @(posedge clk_1khz) begin    // Dieksekusi setiap clock 1 kHz
        scan_idx <= scan_idx + 3'd1;    // Pindah ke baris berikutnya
    end

		// ROW aktif LOW, COL aktif HIGH (tidak di-invert)
		always @(*) begin               // Logika kombinasi untuk memilih baris dan data kolom
			 row_sel = ~(8'b00000001 << scan_idx); // Mengaktifkan satu baris sesuai scan_idx (active LOW)

			 case (scan_idx)            // Memilih data bitmap sesuai baris aktif

				  3'd0: col_data = row0;  // Jika scan_idx=0 tampilkan data row0

				  3'd1: col_data = row1;  // Jika scan_idx=1 tampilkan data row1

				  3'd2: col_data = row2;  // Jika scan_idx=2 tampilkan data row2

				  3'd3: col_data = row3;  // Jika scan_idx=3 tampilkan data row3

				  3'd4: col_data = row4;  // Jika scan_idx=4 tampilkan data row4

				  3'd5: col_data = row5;  // Jika scan_idx=5 tampilkan data row5

				  3'd6: col_data = row6;  // Jika scan_idx=6 tampilkan data row6

				  3'd7: col_data = row7;  // Jika scan_idx=7 tampilkan data row7

				  default: col_data = 8'h00; // Pengaman jika scan_idx di luar rentang
			 endcase
		end

endmodule                                // Akhir modul dotmatrix_driver