// ============================================================
// Module  : debounce
// Fungsi  : Debounce tombol Active LOW
//           Output HIGH selama tombol ditekan
// ============================================================
module debounce (                         // Modul debounce untuk menghilangkan efek bouncing pada tombol
    input  wire clk,                      // Clock yang digunakan sebagai referensi proses debounce
    input  wire btn_in,                   // Input tombol dari pin FPGA
    output reg  btn_out                   // Output tombol yang sudah stabil
);

    reg [19:0] cnt;                       // Counter untuk menghitung waktu debounce
    reg sync_0, sync_1;                   // Register synchronizer dua tahap
    reg stable;                           // Menyimpan status tombol yang sudah dianggap stabil

    initial begin                         // Nilai awal saat FPGA mulai bekerja
        cnt     = 20'd0;                  // Counter dimulai dari 0
        sync_0  = 1'b1;                   // Tombol dianggap tidak ditekan (active LOW)
        sync_1  = 1'b1;                   // Tombol dianggap tidak ditekan (active LOW)
        stable  = 1'b1;                   // Status stabil awal = tidak ditekan
        btn_out = 1'b0;                   // Output awal = LOW
    end

    // ========================================================
    // Synchronizer
    // ========================================================
    always @(posedge clk) begin           // Dieksekusi setiap tepi naik clock
        sync_0 <= btn_in;                 // Tahap sinkronisasi pertama
        sync_1 <= sync_0;                 // Tahap sinkronisasi kedua untuk mengurangi metastability
    end

    // ========================================================
    // Debounce
    // ========================================================
    always @(posedge clk) begin           // Proses debounce dijalankan setiap clock
        if (sync_1 == stable) begin       // Jika kondisi tombol sama dengan kondisi stabil sebelumnya
            cnt <= 10'd0;                 // Reset counter karena tidak ada perubahan
        end
        else begin                        // Jika ada perubahan kondisi tombol
            if (cnt < 10'd999_999)        // Tunggu sampai perubahan cukup lama
                cnt <= cnt + 20'd1;       // Tambah counter setiap clock
            else begin                    // Jika waktu debounce sudah terpenuhi
                stable <= sync_1;         // Simpan kondisi baru sebagai kondisi stabil
                cnt <= 10'd0;             // Reset counter untuk deteksi berikutnya
            end
        end
    end

    // ========================================================
    // Output Active HIGH saat tombol ditekan
    // Karena tombol Active LOW
    // ========================================================
    always @(posedge clk) begin           // Update output setiap clock
        btn_out <= ~stable;               // Membalik logika: tombol LOW menjadi output HIGH
    end

endmodule                                 // Akhir modul