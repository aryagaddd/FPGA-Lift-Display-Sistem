// ============================================================
// Module  : floor_tracker
// Fungsi  : Melacak posisi lantai lift saat ini (lantai 1-4)
//           Update posisi hanya saat lift selesai bergerak
// ============================================================
module floor_tracker (                  // Modul untuk menyimpan dan memperbarui posisi lantai lift
    input  wire       clk_1hz,          // Clock 1 Hz sebagai pemicu perpindahan lantai
    input  wire       move_up_done,     // Pulsa 1 siklus saat proses naik selesai
    input  wire       move_down_done,   // Pulsa 1 siklus saat proses turun selesai
    output reg  [2:0] floor             // Output posisi lantai saat ini (1 sampai 4)
);
    initial floor = 3'd1;               // Saat FPGA mulai bekerja, lift berada di lantai 1

    always @(posedge clk_1hz) begin     // Dieksekusi setiap tepi naik clock 1 Hz

        if (move_up_done && floor < 3'd4) // Jika naik selesai dan belum mencapai lantai tertinggi
            floor <= floor + 3'd1;        // Tambah nomor lantai satu tingkat

        else if (move_down_done && floor > 3'd1) // Jika turun selesai dan belum mencapai lantai terendah
            floor <= floor - 3'd1;               // Kurangi nomor lantai satu tingkat
    end

endmodule                               // Akhir modul