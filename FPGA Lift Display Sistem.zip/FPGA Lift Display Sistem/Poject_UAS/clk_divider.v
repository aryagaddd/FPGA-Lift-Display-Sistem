// ============================================================
// Module  : clk_divider
// Fungsi  : Membagi clock 50MHz menjadi 1Hz dan 1kHz
// ============================================================

module clk_divider (                    // Deklarasi modul bernama clk_divider
    input  wire clk_50mhz,              // Input clock utama FPGA 50 MHz
    output reg  clk_1hz,                // Output clock hasil pembagian menjadi 1 Hz
    output reg  clk_1khz                // Output clock hasil pembagian menjadi 1 kHz
);

    reg [25:0] cnt_1hz;                 // Counter 26-bit untuk menghitung clock 1 Hz
    reg [15:0] cnt_1khz;                // Counter 16-bit untuk menghitung clock 1 kHz

    initial begin                       // Inisialisasi nilai awal saat FPGA mulai bekerja
        clk_1hz  = 0;                   // Clock 1 Hz dimulai dari logika 0
        clk_1khz = 0;                   // Clock 1 kHz dimulai dari logika 0
        cnt_1hz  = 0;                   // Counter 1 Hz direset ke 0
        cnt_1khz = 0;                   // Counter 1 kHz direset ke 0
    end

    always @(posedge clk_50mhz) begin   // Dieksekusi setiap tepi naik clock 50 MHz

        // ==========================
        // Pembangkitan clock 1 Hz
        // ==========================

        // Clock akan toggle setiap 25.000.000 siklus
        // Karena satu periode penuh membutuhkan dua kali toggle,
        // maka frekuensi akhirnya menjadi 1 Hz.
        if (cnt_1hz == 26'd24_999_999) begin

            cnt_1hz <= 0;               // Reset counter setelah mencapai batas

            clk_1hz <= ~clk_1hz;        // Membalik keadaan clock (0→1 atau 1→0)

        end else begin

            cnt_1hz <= cnt_1hz + 1;     // Counter terus bertambah setiap clock

        end

        // ==========================
        // Pembangkitan clock 1 kHz
        // ==========================

        // Clock akan toggle setiap 25.000 siklus
        // Digunakan untuk proses scanning dot matrix agar tampilan stabil.
        if (cnt_1khz == 16'd24_999) begin

            cnt_1khz <= 0;              // Reset counter setelah mencapai batas

            clk_1khz <= ~clk_1khz;      // Membalik keadaan clock 1 kHz

        end else begin

            cnt_1khz <= cnt_1khz + 1;   // Counter terus bertambah setiap clock

        end
    end

endmodule                               // Akhir modul