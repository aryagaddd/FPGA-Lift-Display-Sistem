// ============================================================
// Module  : lift_top (v2)
// Fungsi  : Top level — menghubungkan semua sub-modul
//           Push button: Active LOW
//           Dot matrix : Common Cathode
// ============================================================
module lift_top (                               // Modul paling atas, tempat semua sub-modul disambungkan
    input  wire clk,                            // Clock utama dari FPGA (50 MHz)

    // Push button Active LOW
    input  wire btn_up_raw,                     // Sinyal mentah tombol naik (belum didebounce)
    input  wire btn_down_raw,                   // Sinyal mentah tombol turun (belum didebounce)
    input  wire btn_open_raw,                   // Sinyal mentah tombol buka pintu (belum didebounce)
    input  wire btn_close_raw,                  // Sinyal mentah tombol tutup pintu (belum didebounce)

    // Dot matrix Common Cathode
    output wire [7:0] row,    // ROW aktif LOW   // Memilih baris mana yang aktif (dikirim ke dot matrix)
    output wire [7:0] col,    // COL aktif HIGH  // Menentukan kolom mana yang menyala

    // Buzzer
    output wire buzzer                          // Sinyal output ke buzzer
);

    // --------------------------------------------------------
    // Wire internal
    // --------------------------------------------------------
    wire        clk_1hz;                        // Clock 1 Hz untuk FSM dan floor_tracker
    wire        clk_1khz;                       // Clock 1 kHz untuk scanning dot matrix

    wire        btn_up;                         // Sinyal tombol naik setelah didebounce
    wire        btn_down;                       // Sinyal tombol turun setelah didebounce
    wire        btn_open;                       // Sinyal tombol buka pintu setelah didebounce
    wire        btn_close;                      // Sinyal tombol tutup pintu setelah didebounce

    wire [2:0]  state;                          // State FSM saat ini (IDLE, MOVING_UP, dst)
    wire [4:0]  frame_addr;                     // Alamat frame yang diminta FSM ke ROM
    wire        move_up_done;                   // Pulsa dari FSM ke floor_tracker: naik 1 lantai
    wire        move_down_done;                 // Pulsa dari FSM ke floor_tracker: turun 1 lantai
    wire        buzz_trigger;                   // Pulsa dari FSM ke buzzer_ctrl: bunyikan buzzer
    wire [2:0]  floor;                          // Posisi lantai saat ini dari floor_tracker ke FSM

    wire [7:0]  bmp_row0, bmp_row1, bmp_row2, bmp_row3;  // Data baris 0-3 dari frame_rom ke dot matrix driver
    wire [7:0]  bmp_row4, bmp_row5, bmp_row6, bmp_row7;  // Data baris 4-7 dari frame_rom ke dot matrix driver

    // --------------------------------------------------------
    // Clock Divider
    // --------------------------------------------------------
    clk_divider u_clk (                         // Instansiasi modul pembagi clock
        .clk_50mhz (clk),                       // Input clock 50 MHz dari FPGA
        .clk_1hz   (clk_1hz),                   // Output clock 1 Hz untuk FSM
        .clk_1khz  (clk_1khz)                   // Output clock 1 kHz untuk dot matrix
    );

    // --------------------------------------------------------
    // Debounce — Active LOW push button
    // btn_pulse keluar sebagai Active HIGH
    // --------------------------------------------------------
    // --------------------------------------------------------
    // Debounce — Active LOW push button
    // Output HIGH selama tombol ditekan
    // --------------------------------------------------------
    debounce u_deb_up (                         // Instansiasi debounce untuk tombol naik
        .clk     (clk),                         // Clock utama sebagai referensi waktu debounce
        .btn_in  (btn_up_raw),                  // Input sinyal mentah tombol naik
        .btn_out (btn_up)                       // Output sinyal bersih tombol naik (Active HIGH)
    );

    debounce u_deb_down (                       // Instansiasi debounce untuk tombol turun
        .clk     (clk),                         // Clock utama
        .btn_in  (btn_down_raw),                // Input sinyal mentah tombol turun
        .btn_out (btn_down)                     // Output sinyal bersih tombol turun
    );

    debounce u_deb_open (                       // Instansiasi debounce untuk tombol buka pintu
        .clk     (clk),                         // Clock utama
        .btn_in  (btn_open_raw),                // Input sinyal mentah tombol buka
        .btn_out (btn_open)                     // Output sinyal bersih tombol buka
    );

    debounce u_deb_close (                      // Instansiasi debounce untuk tombol tutup pintu
        .clk     (clk),                         // Clock utama
        .btn_in  (btn_close_raw),               // Input sinyal mentah tombol tutup
        .btn_out (btn_close)                    // Output sinyal bersih tombol tutup
    );

    // --------------------------------------------------------
    // Floor Tracker
    // --------------------------------------------------------
    floor_tracker u_floor (                     // Instansiasi modul pelacak posisi lantai
        .clk_1hz        (clk_1hz),              // Clock 1 Hz sebagai referensi waktu update
        .move_up_done   (move_up_done),         // Terima sinyal dari FSM: lift baru saja naik
        .move_down_done (move_down_done),       // Terima sinyal dari FSM: lift baru saja turun
        .floor          (floor)                 // Output posisi lantai saat ini ke FSM
    );

    // --------------------------------------------------------
    // FSM Lift
    // --------------------------------------------------------
    fsm_lift u_fsm (                            // Instansiasi modul state machine utama lift
        .clk_1hz        (clk_1hz),              // Clock 1 Hz untuk transisi state
        .btn_up         (btn_up),               // Input tombol naik bersih
        .btn_down       (btn_down),             // Input tombol turun bersih
        .btn_open       (btn_open),             // Input tombol buka bersih
        .btn_close      (btn_close),            // Input tombol tutup bersih
        .state          (state),                // Output state aktif saat ini
        .frame_addr     (frame_addr),           // Output alamat frame ke ROM
        .move_up_done   (move_up_done),         // Output pulsa naik ke floor_tracker
        .move_down_done (move_down_done),       // Output pulsa turun ke floor_tracker
        .buzz_trigger   (buzz_trigger),         // Output pulsa ke buzzer_ctrl
        .floor          (floor)                 // Input posisi lantai dari floor_tracker
    );

    // --------------------------------------------------------
    // Buzzer Controller
    // --------------------------------------------------------
    buzzer_ctrl u_buzz (                        // Instansiasi modul pengendali buzzer
        .clk      (clk),                        // Clock utama
        .clk_1hz  (clk_1hz),                   // Clock 1 Hz untuk durasi bunyi
        .trigger  (buzz_trigger),              // Input pulsa dari FSM saat lift tiba di lantai
        .buzzer   (buzzer)                     // Output sinyal ke buzzer fisik
    );

    // --------------------------------------------------------
    // Frame ROM
    // --------------------------------------------------------
    frame_rom u_rom (                           // Instansiasi ROM penyimpan data gambar dot matrix
        .addr (frame_addr),                     // Input alamat frame dari FSM
        .row0 (bmp_row0),                       // Output data baris 0 dari gambar
        .row1 (bmp_row1),                       // Output data baris 1 dari gambar
        .row2 (bmp_row2),                       // Output data baris 2 dari gambar
        .row3 (bmp_row3),                       // Output data baris 3 dari gambar
        .row4 (bmp_row4),                       // Output data baris 4 dari gambar
        .row5 (bmp_row5),                       // Output data baris 5 dari gambar
        .row6 (bmp_row6),                       // Output data baris 6 dari gambar
        .row7 (bmp_row7)                        // Output data baris 7 dari gambar
    );

    // --------------------------------------------------------
    // Dot Matrix Driver — Common Cathode
    // --------------------------------------------------------
    dotmatrix_driver u_dot (                    // Instansiasi driver dot matrix 8x8
        .clk_1khz (clk_1khz),                  // Clock 1 kHz untuk scanning baris satu per satu
        .row0     (bmp_row0),                   // Data baris 0 dari ROM
        .row1     (bmp_row1),                   // Data baris 1 dari ROM
        .row2     (bmp_row2),                   // Data baris 2 dari ROM
        .row3     (bmp_row3),                   // Data baris 3 dari ROM
        .row4     (bmp_row4),                   // Data baris 4 dari ROM
        .row5     (bmp_row5),                   // Data baris 5 dari ROM
        .row6     (bmp_row6),                   // Data baris 6 dari ROM
        .row7     (bmp_row7),                   // Data baris 7 dari ROM
        .row_sel  (row),                        // Output pemilih baris ke dot matrix (Active LOW)
        .col_data (col)                         // Output data kolom ke dot matrix (Active HIGH)
    );

endmodule                                       // Akhir modul lift_top