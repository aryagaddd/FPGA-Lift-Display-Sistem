// ============================================================
// Module  : buzzer_ctrl
// Fungsi  : Membunyikan buzzer selama 1 detik
//           dengan suara lebih keras
// ============================================================
module buzzer_ctrl (                    // Modul pengendali buzzer
    input  wire clk,        // clock 50 MHz
    input  wire clk_1hz,    // timer detik
    input  wire trigger,    // trigger dari FSM
    output reg  buzzer      // Output menuju pin buzzer
);

    // ========================================================
    // Register Internal
    // ========================================================
    reg active;                        // Menandakan buzzer sedang aktif atau tidak

    reg [15:0] tone_cnt;               // Counter pembangkit frekuensi suara

    initial begin                      // Inisialisasi nilai awal
        active   = 1'b0;               // Buzzer awalnya tidak aktif
        tone_cnt = 16'd0;              // Counter dimulai dari 0
        buzzer   = 1'b0;               // Output buzzer awal LOW
    end

    // ========================================================
    // Timer durasi buzzer 1 detik
    // ========================================================
    always @(posedge clk_1hz) begin    // Dieksekusi setiap 1 detik

        // Mulai bunyi
        if (trigger) begin             // Jika ada trigger dari FSM
            active <= 1'b1;            // Aktifkan buzzer
        end

        // Setelah 1 detik langsung mati
        else begin                     // Jika trigger tidak ada
            active <= 1'b0;            // Matikan buzzer
        end
    end

    // ========================================================
    // Generator suara buzzer
    // ========================================================
    always @(posedge clk) begin        // Dieksekusi pada clock 50 MHz

        if (active) begin              // Hanya menghasilkan suara jika buzzer aktif

            // Frekuensi suara buzzer
            if (tone_cnt >= 16'd12500) begin // Jika counter mencapai batas

                tone_cnt <= 16'd0;     // Reset counter

                buzzer   <= ~buzzer;   // Balik kondisi buzzer untuk membentuk gelombang kotak

            end
            else begin                 // Jika belum mencapai batas

                tone_cnt <= tone_cnt + 16'd1; // Tambah counter

            end

        end
        else begin                     // Jika buzzer tidak aktif

            tone_cnt <= 16'd0;         // Reset counter

            buzzer   <= 1'b0;          // Paksa output buzzer menjadi LOW

        end
    end

endmodule                              // Akhir modul