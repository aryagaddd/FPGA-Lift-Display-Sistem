// ============================================================
// TEST SEDERHANA: Tombol langsung nyalakan dot matrix
// Jika tekan BTN_UP   → semua LED baris atas menyala
// Jika tekan BTN_OPEN → semua LED baris bawah menyala
// Tidak ada FSM, tidak ada debounce, tidak ada clock divider
// ============================================================
module lift_top (
    input  wire clk,
    input  wire btn_up_raw,
    input  wire btn_down_raw,
    input  wire btn_open_raw,
    input  wire btn_close_raw,
    output wire [7:0] row,
    output wire [7:0] col,
    output wire buzzer
);
    // ROW aktif LOW — aktifkan semua baris sekaligus
    assign row = 8'b00000000;  // semua baris aktif

    // COL aktif HIGH — nyalakan kolom sesuai tombol
    // Tidak ditekan = gelap, ditekan = menyala
    assign col = {
        ~btn_up_raw,    // col[7]
        ~btn_down_raw,  // col[6]
        ~btn_open_raw,  // col[5]
        ~btn_close_raw, // col[4]
        ~btn_up_raw,    // col[3]
        ~btn_down_raw,  // col[2]
        ~btn_open_raw,  // col[1]
        ~btn_close_raw  // col[0]
    };

    assign buzzer = 0;

endmodule