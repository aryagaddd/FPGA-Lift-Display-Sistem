// ============================================================
// Module  : frame_rom
// Fungsi  : Menyimpan semua pola bitmap 8x8 untuk animasi
// Revisi  : Auto mirror horizontal agar tampilan benar di hardware
// ============================================================
module frame_rom (                       // Modul ROM yang menyimpan seluruh frame animasi dot matrix
    input  wire [4:0]  addr,            // Alamat frame yang ingin ditampilkan (0-31)
    output reg  [7:0]  row0,            // Baris ke-0 dot matrix
    output reg  [7:0]  row1,            // Baris ke-1 dot matrix
    output reg  [7:0]  row2,            // Baris ke-2 dot matrix
    output reg  [7:0]  row3,            // Baris ke-3 dot matrix
    output reg  [7:0]  row4,            // Baris ke-4 dot matrix
    output reg  [7:0]  row5,            // Baris ke-5 dot matrix
    output reg  [7:0]  row6,            // Baris ke-6 dot matrix
    output reg  [7:0]  row7             // Baris ke-7 dot matrix
);

    // ========================================================
    // Fungsi mirror horizontal 8-bit
    // ========================================================
    function [7:0] mirror8;             // Fungsi untuk membalik urutan bit secara horizontal
        input [7:0] data;               // Data bitmap 8-bit yang masuk
        begin
            mirror8 = {
                data[0],                // Bit paling kanan menjadi paling kiri
                data[1],
                data[2],
                data[3],
                data[4],
                data[5],
                data[6],
                data[7]                 // Bit paling kiri menjadi paling kanan
            };
        end
    endfunction                         // Akhir fungsi mirror8

    always @(*) begin                   // Logika kombinasi, langsung berubah saat addr berubah
        case (addr)                     // Memilih frame berdasarkan alamat

            // =================================================
            // LANTAI 1
            // =================================================
            5'd0: begin                 // Frame nomor 0 menampilkan angka 1
                row0 = mirror8(8'b00011000);
                row1 = mirror8(8'b00111000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 2
            // =================================================
            5'd1: begin                 // Frame nomor 1 menampilkan angka 2
                row0 = mirror8(8'b00111100);
                row1 = mirror8(8'b01100110);
                row2 = mirror8(8'b00000110);
                row3 = mirror8(8'b00001100);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00110000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 3
            // =================================================
            5'd2: begin                 // Frame nomor 2 menampilkan angka 3
                row0 = mirror8(8'b00111100);
                row1 = mirror8(8'b01100110);
                row2 = mirror8(8'b00000110);
                row3 = mirror8(8'b00011100);
                row4 = mirror8(8'b00000110);
                row5 = mirror8(8'b01100110);
                row6 = mirror8(8'b00111100);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 4
            // =================================================
            5'd3: begin                 // Frame nomor 3 menampilkan angka 4
                row0 = mirror8(8'b00001100);
                row1 = mirror8(8'b00011100);
                row2 = mirror8(8'b00101100);
                row3 = mirror8(8'b01001100);
                row4 = mirror8(8'b01111110);
                row5 = mirror8(8'b00001100);
                row6 = mirror8(8'b00001100);
                row7 = mirror8(8'b00000000);
            end

           // =================================================
           // PANAH NAIK (REVERSE)
           // =================================================
5'd4: begin                             // Animasi panah naik frame 1
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00000000);
    row2 = mirror8(8'b00000000);
    row3 = mirror8(8'b00011000);
    row4 = mirror8(8'b00111100);
    row5 = mirror8(8'b01111110);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd5: begin                             // Animasi panah naik frame 2
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00000000);
    row2 = mirror8(8'b00011000);
    row3 = mirror8(8'b00111100);
    row4 = mirror8(8'b01111110);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd6: begin                             // Animasi panah naik frame 3
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00011000);
    row2 = mirror8(8'b00111100);
    row3 = mirror8(8'b01111110);
    row4 = mirror8(8'b00011000);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd7: begin                             // Animasi panah naik frame 4
    row0 = mirror8(8'b00011000);
    row1 = mirror8(8'b00111100);
    row2 = mirror8(8'b01111110);
    row3 = mirror8(8'b00011000);
    row4 = mirror8(8'b00011000);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00000000);
    row7 = mirror8(8'b00000000);
end

            // =================================================
            // PANAH TURUN
            // =================================================
            5'd8: begin                 // Animasi panah turun frame 1
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00011000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b01111110);
                row4 = mirror8(8'b00111100);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b00000000);
            end

            5'd9: begin                 // Animasi panah turun frame 2
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b01111110);
                row5 = mirror8(8'b00111100);
                row6 = mirror8(8'b00011000);
                row7 = mirror8(8'b00000000);
            end

            5'd10: begin                // Animasi panah turun frame 3
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b01111110);
                row6 = mirror8(8'b00111100);
                row7 = mirror8(8'b00011000);
            end

            5'd11: begin                // Animasi panah turun frame 4
                row0 = mirror8(8'b00011000);
                row1 = mirror8(8'b00011000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00111100);
            end

            // =================================================
            // PINTU BUKA
            // =================================================
            5'd12: begin
                row0 = mirror8(8'b11100111);
                row1 = mirror8(8'b11100111);
                row2 = mirror8(8'b11100111);
                row3 = mirror8(8'b11100111);
                row4 = mirror8(8'b11100111);
                row5 = mirror8(8'b11100111);
                row6 = mirror8(8'b11100111);
                row7 = mirror8(8'b11111111);
            end

            5'd13: begin
                row0 = mirror8(8'b11000011);
                row1 = mirror8(8'b11000011);
                row2 = mirror8(8'b11000011);
                row3 = mirror8(8'b11000011);
                row4 = mirror8(8'b11000011);
                row5 = mirror8(8'b11000011);
                row6 = mirror8(8'b11000011);
                row7 = mirror8(8'b11111111);
            end

            5'd14: begin
                row0 = mirror8(8'b10000001);
                row1 = mirror8(8'b10000001);
                row2 = mirror8(8'b10000001);
                row3 = mirror8(8'b10000001);
                row4 = mirror8(8'b10000001);
                row5 = mirror8(8'b10000001);
                row6 = mirror8(8'b10000001);
                row7 = mirror8(8'b11111111);
            end

            5'd15: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00000000);
                row5 = mirror8(8'b00000000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b11111111);
            end

            // =================================================
            // PINTU TUTUP
            // =================================================
            5'd16: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00000000);
                row5 = mirror8(8'b00000000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b11111111);
            end

            5'd17: begin
                row0 = mirror8(8'b10000001);
                row1 = mirror8(8'b10000001);
                row2 = mirror8(8'b10000001);
                row3 = mirror8(8'b10000001);
                row4 = mirror8(8'b10000001);
                row5 = mirror8(8'b10000001);
                row6 = mirror8(8'b10000001);
                row7 = mirror8(8'b11111111);
            end

            5'd18: begin
                row0 = mirror8(8'b11000011);
                row1 = mirror8(8'b11000011);
                row2 = mirror8(8'b11000011);
                row3 = mirror8(8'b11000011);
                row4 = mirror8(8'b11000011);
                row5 = mirror8(8'b11000011);
                row6 = mirror8(8'b11000011);
                row7 = mirror8(8'b11111111);
            end

            5'd19: begin
                row0 = mirror8(8'b11100111);
                row1 = mirror8(8'b11100111);
                row2 = mirror8(8'b11100111);
                row3 = mirror8(8'b11100111);
                row4 = mirror8(8'b11100111);
                row5 = mirror8(8'b11100111);
                row6 = mirror8(8'b11100111);
                row7 = mirror8(8'b11111111);
            end

            // =================================================
            // DEFAULT
            // =================================================
            default: begin
                row0 = 8'b00000000;
                row1 = 8'b00000000;
                row2 = 8'b00000000;
                row3 = 8'b00000000;
                row4 = 8'b00000000;
                row5 = 8'b00000000;
                row6 = 8'b00000000;
                row7 = 8'b00000000;
            end
        endcase
    end

endmodule